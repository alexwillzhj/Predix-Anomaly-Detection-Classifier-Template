import time
import json
import cPickle as pickle
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
import numpy as np

class tsAnomalyDetection():

    def __init__(self):
        print "Create python time series demo adder"


    def ts_detection(self, data, modelmap={}):

        res = 0

        # data input
        try:
            data_json = json.loads(data)
        except:
            res = -1
            timestamps = [0]
            return json.dumps({"data": {"time_series":{"time_stamp": [timestamps[0]],"detect_res0": [res]}}})


        try:
            ts_curr = data_json['data']['time_series']['feature']
        except:
            res = -2
            timestamps = [0]
            return json.dumps({"data": {"time_series":{"time_stamp": [timestamps[0]],"detect_res0": [res]}}})

        try:
            timestamps = data_json['data']['time_series']['time_stamp']
        except:
            res = -3
            timestamps = [0]
            return json.dumps({"data": {"time_series": {"time_stamp": [timestamps[0]], "detect_res0": [res]}}})

        # classify
        try:
            # load classifier
            model_file = open('/home/vcap/app/analytics/qda.pkl', 'r')
            qda = pickle.load(model_file)
            model_file.close()

            # classify
            y_pred = qda.predict(ts_curr[0])

            if y_pred == 0:
                res = -5
            elif y_pred == 1:
                res = 5

        except:
            res = -4
            return json.dumps({"data": {"time_series":{"time_stamp": [timestamps[0]],"detect_res0": [res]}}})


        return json.dumps({"data": {"time_series":{"time_stamp": [timestamps[0]],"detect_res0": [res]}}})


    def ts_training(self, data, modelmap={}):

        timestamps = int((time.time() + 1) * 1000)

        model_res = 0

        # data input
        try:
            data_json = json.loads(data)

            ts = data_json['data']['time_series']['numberArray0']
            label = data_json['data']['time_series']['numberArray1']
            model_res = model_res + 1000

        except:
            model_res = model_res + 2000


        if model_res < 2000:
            qda = QuadraticDiscriminantAnalysis(store_covariances=False,priors=(0.9,0.1))
            X = np.array([ts])
            y_pred = qda.fit(X.transpose(), label).predict(X.transpose())

            output = open('qda.pkl', 'wb')
            # Pickle dictionary using protocol 0.
            pickle.dump(qda, output)
            output.close()

        return json.dumps(
            {
                "data":
                    {
                        "time_series":
                            {
                                "time_stamp": [timestamps],
                                "forecast_res0": [model_res]
                            }
                    }
            })
